/*
How to run:
Connect to the drone's Wi-Fi network from your computer. It will be named something like "TELLO-XXXXXX".

Once you are connected you can run the Gobot code on your computer to control the drone.

        go run examples/tello.go
*/

package main

import (
        "os"
        "time"

        "gobot.io/x/gobot"
        "gobot.io/x/gobot/platforms/dji/tello"
)

func main() {
        drone := tello.NewDriver("8888")

        work := func() {
                /* 離陸 */
                drone.TakeOff()

                gobot.After(20*time.Second, func() {
                        /* 着陸 */
                        drone.Land()
                        os.Exit(0)
                })
        }

        robot := gobot.NewRobot("tello",
                []gobot.Connection{},
                []gobot.Device{drone},
                work,
        )

        robot.Start()
}
