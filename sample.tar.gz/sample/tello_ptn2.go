/*
You must have MPlayer (https://mplayerhq.hu) installed in order to run this code. it will connect to the Tello
and then open a window using MPlayer showing the streaming video.

How to run

        go run examples/tello_video.go
*/

package main

import (
        "os"
        "time"

        "gobot.io/x/gobot"
        "gobot.io/x/gobot/platforms/dji/tello"
)

func main() {
        drone := tello.NewDriver("8888")

        work := func() {
                /* scenario */
                /* 離陸 */
                drone.TakeOff()

                gobot.After(10*time.Second, func() {
                        // Clockwise tells drone to rotate in a clockwise direction. Pass in an int from 0-100.
                        /* 時計回り */
                        drone.Clockwise(50)
                })

                gobot.After(20*time.Second, func() {
                        drone.Clockwise(0)
                })

                gobot.After(25*time.Second, func() {
                        /* 着陸 */
                        drone.Land()
                        os.Exit(0)
                })
        }

        robot := gobot.NewRobot("tello",
                []gobot.Connection{},
                []gobot.Device{drone},
                work,
        )

        robot.Start()
}
