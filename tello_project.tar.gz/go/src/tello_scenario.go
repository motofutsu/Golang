/*
You must have MPlayer (https://mplayerhq.hu) installed in order to run this code. it will connect to the Tello
and then open a window using MPlayer showing the streaming video.

How to run

        go run examples/tello_video.go
*/

package main

import (
        "fmt"
        "os"
        "os/exec"
        "time"

        "gobot.io/x/gobot"
        "gobot.io/x/gobot/platforms/dji/tello"
)

func main() {
        drone := tello.NewDriver("8888")

        const layout = "tello_video_0102_150405.wmv" 
        t := time.Now()

        work := func() {
                mplayer_rec := exec.Command("mplayer", "-dumpstream", "-dumpfile", t.Format(layout),
                                            "-cache", "4096", "-fps", "35", "-")
                mplayer_recIn, _ := mplayer_rec.StdinPipe()
                if err := mplayer_rec.Start(); err != nil {
                        fmt.Println(err)
                        return
                }

                mplayer_play := exec.Command("mplayer", "-cache", "4096", "-fps", "35", "-")
                mplayer_playIn, _ := mplayer_play.StdinPipe()
                if err := mplayer_play.Start(); err != nil {
                        fmt.Println(err)
                        return
                }

                drone.On(tello.ConnectedEvent, func(data interface{}) {
                        fmt.Println("Connected")
                        drone.StartVideo()
                        drone.SetVideoEncoderRate(0)
                        gobot.Every(100*time.Millisecond, func() {
                                drone.StartVideo()
                        })
                })

                drone.On(tello.VideoFrameEvent, func(data interface{}) {
                        pkt := data.([]byte)
                        if _, err := mplayer_playIn.Write(pkt); err != nil {
                                fmt.Println(err)
                        }
                        if _, err := mplayer_recIn.Write(pkt); err != nil {
                                fmt.Println(err)
                        }
                })

                //os.Exit(0)

                /* scenario */
                drone.TakeOff()
                time.Sleep(5 * time.Second)

                drone.Forward(20)
                time.Sleep(9 * time.Second)
                drone.Forward(0)

                drone.CounterClockwise(45)
                time.Sleep(3 * time.Second)
                drone.Clockwise(0)

                drone.Up(20)
                time.Sleep(8 * time.Second)
                drone.Up(0)
                time.Sleep(5 * time.Second)

                drone.Down(20)
                time.Sleep(8 * time.Second)
                drone.Up(0)

                drone.Clockwise(45)
                time.Sleep(3 * time.Second)
                drone.Clockwise(0)

                time.Sleep(5 * time.Second)

                drone.Land()
                os.Exit(0)
        }

        robot := gobot.NewRobot("tello",
                []gobot.Connection{},
                []gobot.Device{drone},
                work,
        )

        robot.Start()
}
